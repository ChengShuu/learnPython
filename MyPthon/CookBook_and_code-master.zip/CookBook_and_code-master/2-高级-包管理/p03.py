import p01 as p

stu = p.Student("yueyue", 18)
stu.say()
