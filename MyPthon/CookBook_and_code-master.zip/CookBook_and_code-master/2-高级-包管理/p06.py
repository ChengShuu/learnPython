import sys

print( type(sys.path ))
print( sys.path )

for p in sys.path:
    print(p)
