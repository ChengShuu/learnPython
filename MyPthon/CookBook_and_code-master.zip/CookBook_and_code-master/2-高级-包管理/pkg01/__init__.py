
def inInit():
    print("I am in init of package")