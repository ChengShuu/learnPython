from django.apps import AppConfig


class Case01Config(AppConfig):
    name = 'case01'
