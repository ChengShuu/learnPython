from django.apps import AppConfig


class MyserConfig(AppConfig):
    name = 'MySer'
