from django.apps import AppConfig


class SessConfig(AppConfig):
    name = 'sess'
