from django.apps import AppConfig


class AadminConfig(AppConfig):
    name = 'aadmin'
